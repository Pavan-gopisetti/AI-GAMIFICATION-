import streamlit as st
import json
import random
import os
import pandas as pd
import requests

# Define the API URL for the generative language model
API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

# Function to send API request and get hint or explanation
def chatbot_response(question):
    try:
        # Send a POST request to the API
        response = requests.post(f"{API_URL}?key=AIzaSyD_ySnDcymZXVzViLi0GULdkVDexk0hqCY", json={
            "contents": [{
                "parts": [{"text": question}]
            }]
        })

        # Check if the request was successful (status code 200)
        response.raise_for_status()  # This will raise an error for HTTP issues (non-200 status)

        # Parse the JSON response
        result = response.json()

        # Log the response to inspect its structure in the Streamlit app
        # st.write("Response from API:", result)

        # Extract the text from the response structure
        if 'candidates' in result and len(result['candidates']) > 0:
            content = result['candidates'][0].get('content', {})
            if 'parts' in content and len(content['parts']) > 0:
                # Return only the text content from the API response
                hint_text = content['parts'][0].get('text', "No explanation available.")
                return hint_text.strip()  # Remove any leading/trailing spaces
            else:
                return "No explanation available."
        else:
            return "No explanation available."
    
    except requests.exceptions.RequestException as e:
        # Log any request errors (network issues, invalid URL, etc.)
        st.error(f"Error fetching explanation: {e}")
        return "No explanation available."


# Function to load questions or puzzles from JSON files
def load_data(filename):
    file_path = os.path.join("data", filename)
    if not os.path.exists(file_path):
        st.error(f"⚠️ File not found: {file_path}. Please check if the file exists.")
        return []
    with open(file_path, "r") as file:
        return json.load(file)


# Initialize session state
for key, default in {
    "score": 0,
    "badges": [],
    "answers": {},
    "current_question": 0,
    "quiz_finished": False,
    "username": "",
    "quiz_started": False,
    "page": "Home",
    "current_puzzle": 0,
    "puzzle_answers": {},
    "puzzle_finished": False
}.items():
    if key not in st.session_state:
        st.session_state[key] = default


# UI Design
st.set_page_config(page_title="AI Gamification", layout="wide")
st.title("🎮 AI-Driven Gamification in Teaching & Learning")

# Sidebar Navigation
st.sidebar.title("Navigation")
page_selection = st.sidebar.radio("Go to", ["Home", "Quiz", "Puzzle", "Leaderboard"])

if page_selection:
    st.session_state["page"] = page_selection

# Home Page
if st.session_state["page"] == "Home":
    st.header("Welcome to AI Gamification Platform!")
    st.write("This platform enhances learning using AI-driven quizzes, puzzles, and gamification elements like badges and leaderboards.")

    st.subheader("Enter Your Name to Start the Quiz")
    username = st.text_input("Name:", key="username_input")

    if st.button("Submit"):
        if username.strip():
            st.session_state["username"] = username.strip()
            st.session_state["quiz_started"] = True
            st.session_state["page"] = "Quiz"
            st.rerun()
        else:
            st.error("Please enter a valid name.")

# Quiz Page
if st.session_state["page"] == "Quiz":
    st.header(f"📝 Quiz Time! Welcome, {st.session_state['username']}!")
    unit = st.selectbox("Choose a Unit", [1, 2, 3, 4, 5], key="unit_selection")
    questions = load_data(f"unit{unit}.json")

    if not questions:
        st.warning("No questions available for this unit.")
    else:
        total_questions = len(questions)
        question_idx = st.session_state["current_question"]

        if not st.session_state["quiz_finished"]:
            q = questions[question_idx]
            st.write(f"**Question {question_idx + 1} of {total_questions}:** {q['question']}")
            answer = st.radio("Select an answer:", [""] + q["options"], key=f"unit{unit}_q{question_idx}")

            # Hint Button
            if st.button("Hint"):
                hint = chatbot_response(q['question'])  # Fetch hint using chatbot_response
                st.info(f"💡 Hint: {hint}")

            # Ask AI Button
            if st.button("Ask AI"):
                explanation = chatbot_response(q['question'])  # Fetch explanation using chatbot_response
                st.info(f"🧠 AI Explanation: {explanation}")

            if st.button("Next Question"):
                if answer and answer != "":
                    st.session_state["answers"][question_idx] = answer
                    if question_idx < total_questions - 1:
                        st.session_state["current_question"] += 1
                    else:
                        st.session_state["quiz_finished"] = True
                st.rerun()
        else:
            correct_answers = sum(1 for i, q in enumerate(questions) if st.session_state["answers"].get(i) == q["answer"])
            st.session_state["score"] = correct_answers * 10
            st.success(f"🎉 Quiz Completed! Your final score: {st.session_state['score']}")

# Puzzle Page
if st.session_state["page"] == "Puzzle":
    st.header("🧩 Solve a Puzzle!")
    all_puzzles = []
    for unit in range(1, 6):
        questions = load_data(f"unit{unit}.json")
        all_puzzles.extend(questions)

    total_puzzles = 10

    if not all_puzzles:
        st.warning("No puzzles available.")
    else:
        selected_puzzles = random.sample(all_puzzles, min(total_puzzles, len(all_puzzles)))
        puzzle_idx = st.session_state["current_puzzle"]

        if puzzle_idx < len(selected_puzzles):
            puzzle = selected_puzzles[puzzle_idx]
            st.write(f"**Puzzle {puzzle_idx + 1} of {total_puzzles}:** {puzzle['question']}")

            user_answer = st.text_input("Your Answer:", key=f"puzzle_{puzzle_idx}", on_change=lambda: st.session_state.update({"puzzle_submitted": True}))

            # Hint Button for Puzzle
            if st.button("Hint"):
                hint = chatbot_response(puzzle['question'])  # Fetch hint using chatbot_response
                st.info(f"💡 Hint: {hint}")

            if st.session_state.get("puzzle_submitted", False):
                if user_answer.strip().lower() == puzzle["answer"].lower():
                    st.success("🎉 Correct!")
                    st.session_state["score"] += 10
                else:
                    st.error("❌ Incorrect, try the next one!")

                if puzzle_idx < total_puzzles - 1:
                    st.session_state["current_puzzle"] += 1
                else:
                    st.session_state["puzzle_finished"] = True

                    leaderboard_file = "leaderboard.xlsx"
                    if os.path.exists(leaderboard_file):
                        leaderboard_df = pd.read_excel(leaderboard_file)
                    else:
                        leaderboard_df = pd.DataFrame(columns=["Name", "Score"])

                    new_entry = pd.DataFrame({"Name": [st.session_state["username"]], "Score": [st.session_state["score"]]}).to_excel(leaderboard_file, index=False)

                st.session_state["puzzle_submitted"] = False
                st.rerun()
        else:
            st.success("✅ Puzzle section completed!")

# Leaderboard Page
if st.session_state["page"] == "Leaderboard":
    st.header("🏆 Leaderboard")
    leaderboard_file = "leaderboard.xlsx"
    if os.path.exists(leaderboard_file):
        leaderboard_df = pd.read_excel(leaderboard_file)
        st.dataframe(leaderboard_df.sort_values(by="Score", ascending=False).reset_index(drop=True))
    else:
        st.write("No leaderboard data available.")

    st.subheader(f"Your Score: {st.session_state['score']}")
    st.write(f"Your Badges: {', '.join(st.session_state['badges']) if st.session_state['badges'] else 'No badges yet'}")
    st.progress(min(st.session_state['score'] / 100, 1.0))
